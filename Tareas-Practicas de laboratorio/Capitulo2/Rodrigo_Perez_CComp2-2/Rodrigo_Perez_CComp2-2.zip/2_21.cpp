/* (Displaying Large Letters) Write a program that prints C++ as follows: */

#include <iostream>
using namespace std;

int main() {

    cout << "  CCC\t  +  \t  +  " << endl;
    cout << " C   \t  +  \t  +  " << endl;
    cout << "C    \t+++++\t+++++" << endl;
    cout << " C   \t  +  \t  +  " << endl;
    cout << "  CCC\t  +  \t  +" << endl;

    return 0;
}