/* What does the following code print? 
cout << "*****\n****\n***\n **\n*\n " << endl; */

#include <iostream>
using namespace std;

int main() {

    cout << "*****\n****\n***\n **\n*\n " << endl;

    return 0;
}

// Un triangulo medio chueco