/* (Checkerboard Pattern) Display the following checkerboard pattern with eight output statements, 
then display the same pattern using as few statements as possible. */

#include <iostream>
using namespace std;

int main() {
    
    cout << "* * * * * * * *" << endl;
    cout << " * * * * * * * " << endl;
    cout << "* * * * * * * *" << endl;    
    cout << " * * * * * * * " << endl;
    cout << "* * * * * * * *" << endl;
    cout << " * * * * * * * " << endl;
    cout << "* * * * * * * *" << endl;
    cout << " * * * * * * * " << endl;

// cout << "\n* * * * * * * *\n * * * * * * * \n* * * * * * * *\n * * * * * * * \n* * * * * * * *\n * * * * * * * \n* * * * * * * *\n * * * * * * * " <<

    return 0;
}


